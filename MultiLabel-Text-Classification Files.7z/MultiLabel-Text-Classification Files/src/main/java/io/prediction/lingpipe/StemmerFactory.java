package io.prediction.lingpipe;

import java.nio.CharBuffer;
import java.util.HashMap;

import org.apache.lucene.analysis.ar.ArabicNormalizer;
import org.apache.lucene.analysis.ar.ArabicStemmer;
import org.carrot2.core.LanguageCode;
import org.carrot2.text.linguistic.IStemmer;
import org.carrot2.text.linguistic.IStemmerFactory;
import org.carrot2.util.ReflectionUtils;
import org.slf4j.Logger;
import org.tartarus.snowball.SnowballProgram;
import org.tartarus.snowball.ext.DanishStemmer;
import org.tartarus.snowball.ext.DutchStemmer;
import org.tartarus.snowball.ext.EnglishStemmer;
import org.tartarus.snowball.ext.FinnishStemmer;
import org.tartarus.snowball.ext.FrenchStemmer;
import org.tartarus.snowball.ext.GermanStemmer;
import org.tartarus.snowball.ext.HungarianStemmer;
import org.tartarus.snowball.ext.ItalianStemmer;
import org.tartarus.snowball.ext.NorwegianStemmer;
import org.tartarus.snowball.ext.PortugueseStemmer;
import org.tartarus.snowball.ext.RomanianStemmer;
import org.tartarus.snowball.ext.RussianStemmer;
import org.tartarus.snowball.ext.SpanishStemmer;
import org.tartarus.snowball.ext.SwedishStemmer;
import org.tartarus.snowball.ext.TurkishStemmer;


public class StemmerFactory implements IStemmerFactory {
    final static Logger logger = org.slf4j.LoggerFactory
            .getLogger(StemmerFactory.class);

    @Override
    public IStemmer getStemmer(LanguageCode language) {
        switch (language) {
            case ARABIC:
                return ArabicStemmerFactory.createStemmer();

            case CHINESE_SIMPLIFIED:
                return IdentityStemmer.INSTANCE;

            default:

                 return SnowballStemmerFactory.createStemmer(language);
        }
    }

    private final static class SnowballStemmerFactory {

     private static HashMap<LanguageCode, Class<? extends SnowballProgram>> snowballStemmerClasses;
        static {
            snowballStemmerClasses = new HashMap<LanguageCode, Class<? extends SnowballProgram>>();
            snowballStemmerClasses.put(LanguageCode.DANISH, DanishStemmer.class);
            snowballStemmerClasses.put(LanguageCode.DUTCH, DutchStemmer.class);
            snowballStemmerClasses.put(LanguageCode.ENGLISH, EnglishStemmer.class);
            snowballStemmerClasses.put(LanguageCode.FINNISH, FinnishStemmer.class);
            snowballStemmerClasses.put(LanguageCode.FRENCH, FrenchStemmer.class);
            snowballStemmerClasses.put(LanguageCode.GERMAN, GermanStemmer.class);
            snowballStemmerClasses
                    .put(LanguageCode.HUNGARIAN, HungarianStemmer.class);
            snowballStemmerClasses.put(LanguageCode.ITALIAN, ItalianStemmer.class);
            snowballStemmerClasses
                    .put(LanguageCode.NORWEGIAN, NorwegianStemmer.class);
            snowballStemmerClasses.put(LanguageCode.PORTUGUESE,
                    PortugueseStemmer.class);
            snowballStemmerClasses.put(LanguageCode.ROMANIAN, RomanianStemmer.class);
            snowballStemmerClasses.put(LanguageCode.RUSSIAN, RussianStemmer.class);
            snowballStemmerClasses.put(LanguageCode.SPANISH, SpanishStemmer.class);
            snowballStemmerClasses.put(LanguageCode.SWEDISH, SwedishStemmer.class);
            snowballStemmerClasses.put(LanguageCode.TURKISH, TurkishStemmer.class);
        }


        private static class SnowballStemmerAdapter implements IStemmer {
            private final SnowballProgram snowballStemmer;

            public SnowballStemmerAdapter(SnowballProgram snowballStemmer) {
                this.snowballStemmer = snowballStemmer;
            }

            @Override
            public CharSequence stem(CharSequence word) {
                snowballStemmer.setCurrent(word.toString());
                if (snowballStemmer.stem()) {
                    return snowballStemmer.getCurrent();
                } else {
                    return null;
                }
            }
        }

        public static IStemmer createStemmer(LanguageCode language) {
            final Class<? extends SnowballProgram> stemmerClazz = snowballStemmerClasses
                    .get(language);

            if (stemmerClazz == null) {
                logger.warn("No Snowball stemmer class for: " + language.name()
                        + ". Quality of clustering may be degraded.");
                return IdentityStemmer.INSTANCE;
            }

            try {
                return new SnowballStemmerAdapter(stemmerClazz.newInstance());
            } catch (Exception e) {
                logger.warn("Could not instantiate snowball stemmer"
                        + " for language: " + language.name()
                        + ". Quality of clustering may be degraded.", e);

                return IdentityStemmer.INSTANCE;
            }
        }
    }

    private static class ArabicStemmerFactory {
        static {
            try {
                ReflectionUtils.classForName(ArabicStemmer.class.getName(), false);
                ReflectionUtils.classForName(ArabicNormalizer.class.getName(), false);
            } catch (ClassNotFoundException e) {
                logger
                        .warn(
                                "Could not instantiate Lucene stemmer for Arabic, clustering quality "
                                        + "of Arabic content may be degraded. For best quality clusters, "
                                        + "make sure Lucene's Arabic analyzer JAR is in the classpath",
                                e);
            }
        }


        private static class LuceneStemmerAdapter implements IStemmer {
            private final org.apache.lucene.analysis.ar.ArabicStemmer delegate;
            private final org.apache.lucene.analysis.ar.ArabicNormalizer normalizer;

            private char[] buffer = new char[0];

            private LuceneStemmerAdapter() {
                delegate = new org.apache.lucene.analysis.ar.ArabicStemmer();
                normalizer = new org.apache.lucene.analysis.ar.ArabicNormalizer();
            }

            @Override
            public CharSequence stem(CharSequence word) {
                if (word.length() > buffer.length) {
                    buffer = new char[word.length()];
                }

                for (int i = 0; i < word.length(); i++) {
                    buffer[i] = word.charAt(i);
                }

                int newLen = normalizer.normalize(buffer, word.length());
                newLen = delegate.stem(buffer, newLen);

                if (newLen != word.length() || !equals(buffer, newLen, word)) {
                    return CharBuffer.wrap(buffer, 0, newLen);
                }

                // Same-same.
                return null;
            }

            private boolean equals(char[] buffer, int len, CharSequence word) {
                assert len == word.length();

                for (int i = 0; i < len; i++) {
                    if (buffer[i] != word.charAt(i))
                        return false;
                }

                return true;
            }
        }

        public static IStemmer createStemmer() {
            try {
                return new LuceneStemmerAdapter();
            } catch (Throwable e) {
                return IdentityStemmer.INSTANCE;
            }
        }
    }

    private static class IdentityStemmer implements IStemmer {
        private final static IdentityStemmer INSTANCE = new IdentityStemmer();

        @Override
        public CharSequence stem(CharSequence word) {
            return null;
        }
    }
}